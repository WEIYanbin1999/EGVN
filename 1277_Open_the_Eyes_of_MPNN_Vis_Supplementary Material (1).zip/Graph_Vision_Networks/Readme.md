### Go to correct direction
For Planetoid datasets (Cora, Citeseer and Pubmed):
~~~
cd Graph_Vision_Networks/experiments/experiment_planetoid
~~~
For OGBL datasets (ogbl-collab, ogbl-ppa, ogbl-citation2, ogbl-ddi)
~~~
cd Graph_Vision_Networks/experiments/experiment_ogbl
~~~
### Run the scripts to re-Produce the results
Please go to ./scripts
1. Find the model as the  {model_name}.sh
2. Find the command to run for specific dataset
3. Run the command